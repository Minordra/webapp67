console.log("this is my script file from javascript"); //แสดงผลในconsole
document.getElementById("text").innerHTML="Pantakran Namjanda"; /* ใช้สำหรับหลายๆหน้า */
document.write("Hello document write"); /* ใช้สำหรับบางหน้า */
window.alert("welcome to my page"); /* ใช้สำหรับแจ้งเตือน */
