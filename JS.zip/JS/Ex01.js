const matches =(obj,source) => Object.keys(source).every(key=>obj.hasOwnProperty(key) && obj[key] === source[key]);
console.log(matches({age:21,beard:true},{age:21,beard:true}));
console.log(matches({firstname:"Pantakran",lastname:"Namjanda",beard:false},{name:"Pantakran Namjanda",beard:false}))