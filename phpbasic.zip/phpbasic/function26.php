<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Write Message</title>
</head>
<body>
    <?php
        function writeMessage()//start function
        {
            echo "This is first function for write message<br>";
            echo "Have a nice program";
        }//stop function
        writeMessage();//เรียกใช้Function
    ?>
</body>
</html>